package userHackathon.service;

import userHackathon.dao.AlunoDao;
import userHackathon.model.Aluno;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

public class AlunoService {

    // Método para listar os alunos na tabela da GUI
    public List<Aluno> listar() {
        try {
            var dao = new AlunoDao();
            return dao.listar();
        } catch (Exception e) {
            System.out.println("[Service] Erro ao listar alunos: " + e.getMessage());
            return new ArrayList<>(); // Retorna lista vazia segura para a GUI não travar
        }
    }

    // CORRIGIDO: Método unificado que a sua AlunoGUI vai chamar!
    // Ele decide se insere ou atualiza e retorna um boolean de sucesso
    public boolean salvarAluno(Aluno aluno) {
        if (aluno == null) {
            System.out.println("[Service] Aluno inválido (nulo).");
            return false;
        }
        try {
            var dao = new AlunoDao();

            // CORREÇÃO DO ERRO: Se o período vier nulo da tela, define como 1 por padrão
            if (aluno.getPeriodo() == null) {
                aluno.setPeriodo(1); // Define 1º período por padrão para não quebrar o banco
            }

            // Se o ID for nulo, significa que é um novo cadastro no banco
            if (aluno.getId() == null) {
                dao.inserir(aluno);
            } else {
                dao.atualizar(aluno);
            }
            return true;

        } catch (Exception e) {
            System.out.println("[Service] Erro ao salvar aluno: " + e.getMessage());
            return false;
        }
    }

    // CORRIGIDO: Ajustada a validação para >= 7 para evitar que o app feche sozinho
    public void importarTxt(File arquivo) throws Exception {
        try (BufferedReader br = new BufferedReader(new FileReader(arquivo))) {
            String linha;
            while ((linha = br.readLine()) != null) {
                if (linha.trim().isEmpty()) continue; // Pula linhas vazias

                String[] dados = linha.split(";");
                // Como você acessa até o índice 6 (dados[6]), o tamanho mínimo do array deve ser 7
                if (dados.length >= 7) {
                    Aluno novo = new Aluno();
                    novo.setNome(dados[0].trim());
                    novo.setCpf(dados[1].trim());
                    novo.setEmail(dados[2].trim());
                    novo.setTelefone(dados[3].trim());
                    novo.setCurso(dados[4].trim());
                    // novo.setPeriodo(dados[5].trim()); // Se for usar futuramente
                    novo.setDataNascimento(dados[6].trim());

                    // Salva usando o método corrigido
                    this.salvarAluno(novo);
                }
            }
        }
    }
}